import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class Carousel extends StatelessWidget {
  const Carousel({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return CarouselSlider(
      items: List.generate(
          10,
          (index) => Image.network(
                "https://www.shutterstock.com/image-vector/sale-banner-template-design-big-600w-1514391125.jpg",
                width: double.infinity,
                height: 160,
                fit: BoxFit.cover,
              )),
      options:
          CarouselOptions(height: 160.0, autoPlay: true, viewportFraction: 1),
    );
  }
}
