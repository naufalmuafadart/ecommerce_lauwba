import 'package:flutter/material.dart';
import 'package:provider/provider.dart';


class ListCategory extends StatelessWidget {
  const ListCategory({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 70,
      margin: const EdgeInsets.symmetric(vertical: 5),
      child: ListView.builder(
        itemCount: 3,
        scrollDirection: Axis.horizontal,
        itemBuilder: (context, index) {

          return GestureDetector(
            onTap: () {
              // Navigator.of(context).pushNamed(SUBCATEGORY_SCREEN);
            },
            child: Container(
              width: 200,
              margin: const EdgeInsets.only(right: 5),
              child: Card(
                child: ListTile(
                  leading: Image.network(
                    "https://static.nike.com/a/images/t_PDP_1280_v1/f_auto,q_auto:eco/451b4531-1090-4044-ad0f-fa9e2b6cd902/streakfly-road-racing-shoes-V17qZm.png",
                  ),
                  title: Text("Sepatu"),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
